function History() {
  return (
    <aside className="history-panel">
      <h2>History</h2>
      <ul>
        <li className="history-item">Session 1</li>
        <li className="history-item">Session 2</li>
        <li className="history-item">Session 3</li>
      </ul>
    </aside>
  );
}

export default History;