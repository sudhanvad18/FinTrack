import '../styles/Spinner.css'

function Spinner() {
  return <div className="spinner"></div>
}

export default Spinner